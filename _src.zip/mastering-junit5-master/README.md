# Mastering JUnit 5

This project contains code examples of [JUnit 5].

# About

This is a project made by [Boni Garcia], Assistant Professor at [U-tad] and Researcher at [Universidad Rey Juan Carlos], Spain. Copyright &copy; 2017.

[JUnit 5]: http://junit.org/junit5/
[Boni Garcia]: http://bonigarcia.github.io/
[U-tad]: http://www.u-tad.com/
[Universidad Rey Juan Carlos]: https://www.urjc.es/
